#!/bin/bash
rm *~
